//
//  maze.cpp
//  Homework3
//
//  Created by Oscar Cheng on 2020/5/7.
//  Copyright © 2020 Oscar Cheng. All rights reserved.
//

class Coord
{
  public:
    Coord(int rr, int cc) : m_row(rr), m_col(cc) {}
    int r() const { return m_row; }
    int c() const { return m_col; }
  private:
    int m_row;
    int m_col;
};

bool pathExists(char maze[][10], int sr, int sc, int er, int ec)
{
    if(sr==er && sc==ec)//If the start location is equal to the ending location, then we've solved the maze, so return true.
        return true;
    maze[sr][sc] = 'O'; //Mark the start location as visted.
    if(sr+1<=9 && maze[sr+1][sc]=='.')
    {
        maze[sr+1][sc]='O';
        if(pathExists(maze,sr+1,sc,er,ec))
            return true;
    }
    if(sr-1>=0 && maze[sr-1][sc]=='.')
    {
        maze[sr-1][sc]='O';
        if(pathExists(maze,sr-1,sc,er,ec))
            return true;
    }
    if(sc+1<=9 && maze[sr][sc+1]=='.')
    {
        maze[sr][sc+1]='O';
        if(pathExists(maze,sr,sc+1,er,ec))
            return true;
    }
    if(sr-1>=0 && maze[sr][sc-1]=='.')
    {
        maze[sr][sc-1]='O';
        if(pathExists(maze,sr,sc-1,er,ec))
            return true;
    }
    return false;
}
