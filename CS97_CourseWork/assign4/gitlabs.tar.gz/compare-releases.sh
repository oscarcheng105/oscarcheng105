#!/bin/sh
git diff $1 $2
