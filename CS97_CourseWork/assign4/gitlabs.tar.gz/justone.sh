#!/bin/sh
git diff HEAD^1 HEAD
