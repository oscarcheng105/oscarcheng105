/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_306(unsigned x)
{
    return x + 3347663093U;
}

void setval_237(unsigned *p)
{
    *p = 2428995912U;
}

unsigned getval_340()
{
    return 3260607562U;
}

unsigned addval_472(unsigned x)
{
    return x + 3277376535U;
}

unsigned addval_344(unsigned x)
{
    return x + 3284650312U;
}

void setval_183(unsigned *p)
{
    *p = 164073560U;
}

unsigned getval_468()
{
    return 3281031256U;
}

void setval_164(unsigned *p)
{
    *p = 3284638024U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_291(unsigned x)
{
    return x + 3676361097U;
}

unsigned getval_165()
{
    return 3678978697U;
}

unsigned getval_408()
{
    return 3676360333U;
}

void setval_497(unsigned *p)
{
    *p = 3682913929U;
}

unsigned getval_265()
{
    return 3286272328U;
}

unsigned getval_487()
{
    return 2428668242U;
}

void setval_286(unsigned *p)
{
    *p = 3221803401U;
}

unsigned addval_118(unsigned x)
{
    return x + 3682910729U;
}

unsigned getval_403()
{
    return 3353381192U;
}

unsigned getval_304()
{
    return 2464188744U;
}

unsigned addval_212(unsigned x)
{
    return x + 3525365384U;
}

void setval_167(unsigned *p)
{
    *p = 3766569123U;
}

unsigned getval_463()
{
    return 3381972617U;
}

unsigned addval_386(unsigned x)
{
    return x + 3265915071U;
}

unsigned addval_203(unsigned x)
{
    return x + 3375940233U;
}

unsigned addval_475(unsigned x)
{
    return x + 3682914713U;
}

void setval_292(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_481(unsigned x)
{
    return x + 3222851209U;
}

unsigned getval_464()
{
    return 3224949001U;
}

unsigned addval_492(unsigned x)
{
    return x + 3674260105U;
}

void setval_153(unsigned *p)
{
    *p = 3223375497U;
}

unsigned addval_295(unsigned x)
{
    return x + 2425668233U;
}

void setval_387(unsigned *p)
{
    *p = 3225996937U;
}

unsigned addval_471(unsigned x)
{
    return x + 3373846921U;
}

void setval_103(unsigned *p)
{
    *p = 3523792523U;
}

unsigned addval_419(unsigned x)
{
    return x + 3286270280U;
}

unsigned getval_195()
{
    return 2425409933U;
}

void setval_181(unsigned *p)
{
    *p = 2425541001U;
}

unsigned getval_107()
{
    return 3380138377U;
}

unsigned addval_342(unsigned x)
{
    return x + 3286272328U;
}

void setval_318(unsigned *p)
{
    *p = 3376988809U;
}

void setval_333(unsigned *p)
{
    *p = 3286270280U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
